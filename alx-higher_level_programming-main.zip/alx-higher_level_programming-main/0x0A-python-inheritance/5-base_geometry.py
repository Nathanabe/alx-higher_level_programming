#!/usr/bin/python3
""" Module base geometry
"""


class BaseGeometry:
    """ empty class"""
    pass

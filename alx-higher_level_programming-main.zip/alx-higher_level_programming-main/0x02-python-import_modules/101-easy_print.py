#!/usr/bin/python3
import easy_print_101

#!/usr/bin/python3
"""Empty class Square that defines a square"""


class Square:
    """Empty class Square that defines a square"""
    pass
